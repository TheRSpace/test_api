<?php

namespace app\models;

interface ProductAttributesStrategy
{
    public function getAttributes();
}
